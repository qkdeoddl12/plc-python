-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        10.4.8-MariaDB - mariadb.org binary distribution
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 plc.plc_log 구조 내보내기
CREATE TABLE IF NOT EXISTS `plc_log` (
  `createTime` varchar(50) DEFAULT '',
  `code_name` varchar(50) DEFAULT '',
  `address` varchar(50) DEFAULT NULL,
  `unit_id` int(11) unsigned DEFAULT NULL,
  `value` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 테이블 데이터 plc.plc_log:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `plc_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `plc_log` ENABLE KEYS */;

-- 테이블 plc.server_info 구조 내보내기
CREATE TABLE IF NOT EXISTS `server_info` (
  `mIDX` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `machine_ip` varchar(50) DEFAULT NULL,
  `machine_plc` int(11) DEFAULT NULL,
  PRIMARY KEY (`mIDX`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- 테이블 데이터 plc.server_info:~5 rows (대략적) 내보내기
/*!40000 ALTER TABLE `server_info` DISABLE KEYS */;
INSERT INTO `server_info` (`mIDX`, `machine_name`, `machine_ip`, `machine_plc`) VALUES
	(1, '설비1', '192.168.1.10', NULL),
	(2, '설비2', '192.168.1.11', NULL),
	(3, '설비3', '192.168.1.12', NULL),
	(4, '설비4', '192.168.1.13', NULL),
	(5, '설비5', '192.168.1.14', NULL);
/*!40000 ALTER TABLE `server_info` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
